USE [msdb]
GO

/****** Object:  Job [Policy - Enable FAILED Server Audit]    Script Date: 04/18/2009 11:09:17 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Policy]    Script Date: 04/18/2009 11:09:17 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Policy' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Policy'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Policy - Enable FAILED Server Audit', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job will be executed when Server Audit Status (STARTED) has been violated and will be executed by the Alert "Server Audit Status Policy Violation"', 
		@category_name=N'Policy', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Enable Server Audit]    Script Date: 04/18/2009 11:09:17 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Enable Server Audit', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*
=========================================================================
    Author:     Ayad Shammout
    Date:		April 17, 2009
    Purpose:    Re-enable All Server Audits if Status = "RUNTIME_FAILED"
				or Status = "STARTED_FAILED"
    
    Returns:  	messages to confirm that Audit disabled then enabled
=========================================================================    
*/


Declare @str varchar(512) 

--Declare a cursor if there are more than one Audit created
Declare FailedAudit cursor scroll for
Select name from sys.dm_server_audit_status 
Where status = 0 or status = 2

Open FailedAudit
Fetch next from FailedAudit Into @Str

While @@fetch_status = 0
BEGIN
 
  --Disable Server Audit
  Execute (''ALTER SERVER AUDIT [''+@str+''] WITH (STATE = OFF)'')
  Print ''Disable Server Audit: ''+@str
  
  --Enable Server Audit
  Execute ( ''ALTER SERVER AUDIT [''+@str+''] WITH (STATE = ON)'')
  Print ''Enable Server Audit: ''+@str
  
  Fetch next from FailedAudit Into @Str
End

Close FailedAudit
Deallocate FailedAudit  ', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO



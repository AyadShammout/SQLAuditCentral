USE [msdb]
GO

/****** Object:  Alert [Server Audit Status Policy Violation]    Script Date: 04/18/2009 11:09:52 ******/
EXEC msdb.dbo.sp_add_alert @name=N'Server Audit Status Policy Violation', 
		@message_id=34052, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@event_description_keyword=N'Server Audit Status (Started)', 
		@category_name=N'[Uncategorized]', 
		@job_name=N'Policy - Enable FAILED Server Audit'
GO


